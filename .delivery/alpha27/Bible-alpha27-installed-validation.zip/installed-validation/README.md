# Bible alpha27 — installed-validation

Actual GNOME49/GTK4.20.4 installed Flatpak and software-GL main CI. Additional real Semeur tests reuse byte-identical candidate311f148 application tree; receipt records candidate source separately. FR/EN Greek/Hebrew, introductions, places/photos, offline fonts/icons and first-scroll/cache diagnostics.

Open overview.html for the original unedited PNGs. See VALIDATION.md for actual checks, measurements, source boundaries and client steps. SHA256SUMS covers every evidence file. No profiles, databases, full Bible modules, credentials or unsigned test installers are included. All issues remain open for client acceptance.
