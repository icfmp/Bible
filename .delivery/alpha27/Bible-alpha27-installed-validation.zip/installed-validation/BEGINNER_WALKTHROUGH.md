# Original words: beginner walkthrough

1. In Semeur Mark7:4, select text and choose **Original text**. The passage and translation provide context. **Greek text** contains the original-language words; they are not claimed to match individual French words. Choose one word.
2. The next screen explains the selected form. **Common meanings** shows the real installed STEP lexical entry. Some glosses are English; this is identified explicitly. A dictionary's possible meanings are not automatically the exact contextual meaning in this verse. Open **Linguistic details** only if you want lemma, source identifier or morphology.
3. Choose **Other occurrences** to explore the same lexical identity in its stated source corpus. Open a reference preview and use Back to return: occurrences → word → passage. Try Genesis1:1 for the Hebrew/RTL path.

Actual installed Semeur, Greek/Hebrew, native keyboard, preview/back navigation and offline paths passed in French/English. No AI meaning, guessed translation alignment or fabricated French gloss is supplied. Client acceptance remains open: please try this without developer guidance and report any screen whose purpose or next action you still cannot understand.
