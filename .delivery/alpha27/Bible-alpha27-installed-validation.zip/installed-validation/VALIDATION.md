# Bible 0.1.0-alpha.27

This batch delivers the native reading, study, Library and Notes follow-ups in PR #244. It preserves downloaded Scripture, canonical references, annotations, linked passages, preferences and offline study resources. No profile reset or note schema change is required. All 25 implementation issues remain open for client acceptance.

## Changes since alpha.26

- **Cards and original words (#204–#206):** compact, visibly actionable native cards across references, text/theme results, occurrences, places and Notes; independent embedded citation links; no redundant hover preview. A progressive passage → word → occurrences flow explains Greek/Hebrew exploration and keeps technical details secondary. Real English STEP glosses are identified honestly; no French lexical text or translation alignment is invented.
- **Icons and offline fonts (#207–#211, #220):** consistently use the requested dictionary, notebook, location, filter and talking symbols, removing unused custom assets. Four unavailable runtime symbols are supplied as the client's explicitly approved, pinned official CC0 SVGs. Roboto and Roboto Serif ship with their licenses and work offline; existing saved font choices remain intact. Translation-note markers preserve exact locators, mouse and keyboard activation.
- **Library and installation (#212–#214):** repair packaged AppStream metadata and GNOME Software details; update existing Library rows without rebuilding the visible model; automatically open the first usable downloaded Bible and repair only an unusable active reader, preserving valid reading/Notes sessions and unsavable drafts.
- **Places and Study (#218–#226):** reviewed, separately maintained place context with documented identities, uncertainty and attribution; optional hash-checked Jerusalem photo with bounded cache and full-image viewer. Remove redundant translation-notes and commentary overflow controls while retaining inline notes and unique contextual navigation. Simplify search loading, Study tabs and Aa grouping; restore one native resizable divider; make book introductions discoverable and render source headings, paragraphs and emphasis faithfully. A measured libshumate lost one-shot frame wakeup is repaired in the existing native packaging patch.
- **Selection and commentary (#227–#228):** show the Original text label in the adaptive toolbar; preserve native backdrop caching and immediate dismissal on scroll. Commentary can continue and reverse across chapter boundaries in ordinary and immersive reading using a bounded entry window; Bible text loading remains unchanged.
- **Notes (#230–#232):** consistent compact quick, inline, workspace and summary surfaces; source context remains separate from the user's text; labels, linked passages and confirmed deletion stay accessible. Remove redundant wide Filters and Study follow/collection buttons while preserving adaptive sidebar access, manual browsing, automatic following, drafts and the main Notes route. Summary cards show the user's note rather than repeating Scripture/translation, as specified in #205.

## Verified source, build and publication

- PR: https://github.com/icfmp/Bible/pull/244 (merged).
- Exact source/tag: `b8142132c9655abeda03292c6382512c198a557c`.
- Main CI: https://github.com/icfmp/Bible/actions/runs/42411803046 and restore check https://github.com/icfmp/Bible/actions/runs/42411802981 — successful.
- Signed channel deployment: https://github.com/icfmp/Bible/actions/runs/42413962294 — attempt 2 successful, reusing the same verified build. Attempt 1 published Pages but encountered a transient HTTP503 at the immediate public-update check; the successful retry and independent retained-profile update verified the final public repository.
- Public installed-profile alpha.26 → alpha.27 update: https://github.com/icfmp/Bible/actions/runs/42411810775 — successful, same profile and resources retained.
- Final signed OSTree: `86936bc90a52e1efdf918d68e97d8ce3409ad0c017dc69d9b3eab8f55499374d`.
- Existing signing fingerprint: `47A17230403EA4953745E6E020EB9FFCCECAFD8F`.
- Matching [source archive](https://github.com/icfmp/Bible/releases/download/alpha-source-archives/Bible-b8142132c9655abeda03292c6382512c198a557c-sources.tar.gz), SHA256 `49cd93a3cd7bf1bb2d6f655c32ac2410aa119fb42c5d3b59db071633fad58eae`.

No application rebuild or tag movement was performed to create this numbered release. Unrelated open PRs #242 and #245 are not included.

## Tests and actual application evidence

- Host suite: 497 tests, 26 environment skips; French suite: 183 tests, 2 skips. Native pointer/keyboard/citation actions, 360px/150% editor and draft guards, backup/linked-reference compatibility and real CrossWire integration passed.
- The actually built and installed GNOME49/GTK4.20.4 Flatpak passed its 264-test suite, 13 immersion tests, 7 selection/inline tests, actual YouVersion opening, real study/navigation/offline checks, software-GL rendering/cache checks and sustained/reversing scrolling in single, parallel and Study modes.
- [Additional exact-bundle tests](https://github.com/icfmp/Bible/actions/runs/42411253489) downloaded and converted actual Semeur BDS resources, then exercised offline French/English Greek Mark7:4 and Hebrew Genesis1:1, occurrences/back navigation, Jeremiah introductions including the last paragraph, packaged icons/fonts and a 360px dark place dialog. The tested candidate tree is byte-identical to the merged application tree.
- GNOME Software46 was checked with the actual local bundle and again after the signed public update: name, icon, description and real application screenshot are visible from `bible-alpha`.
- Retained-profile checks preserved the synthetic linked note/labels, highlights, saved typography, session and downloaded modules/study data. The preservation receipt records 27 module files, 5 study files and the same profile reused. These tests do not inspect or reset the client's own profile.
- Actual GTK screenshots are attached as evidence archives. Each archive identifies its source/environment. The new before/after captures use exact alpha.26 `6faab9201d4fdf496ccb931c62b1cf9aa9e7f233` versus merged `b814213`, matched saved DejaVu Serif14, GTK4.18.6/X11/Cairo, French/English, light/dark and wide/narrow windows; they are **development captures**, separately labeled from installed-Flatpak GTK4.20.4/GL captures. All PNGs are unedited native captures. Old temporary development captures were lost on environment resume; replacement captures were recorded on 8 November without changing the application. Notes in capture profiles are synthetic, downloaded Scripture is real, and no profile/database/full translation is distributed in the evidence.

## Measurements and limits

- Actual installed main-build GL wheel input: first motion **0.84–1.22ms**, first usable GTK paint **13.80–20.99ms** across single/toolbar/parallel/Study cases. With the toolbar initially open: input→dismiss start **0.18ms**, dismissal **0.22ms**, first motion **1.11ms**, first paint **14.74ms**; the bar is hidden before paint, backdrop released and placement stopped. Direction reversals remained responsive and post-stop checks passed. These are measured CI-machine timings, not a benchmark of the client's computer.
- Cached visible-idle and dismissed/hidden backdrop checks recorded **zero** Python snapshot/change/adapt/watch calls. A deliberate diagnostic control that keeps the bar visible while moving its background by scrollbar adjustment remains expensive: ~226.84% of one CPU versus ~30.16% without the bar, ~1.83% idle, ~29.28% after dismissal. Normal wheel gestures dismiss on the first event; this control is not normal wheel behavior. Raw measurements and method are included rather than hidden.
- Four actual BDS/Segond × MHC/Wesley commentary combinations completed eight forward/reverse cycles. Alpha.26 stopped at chapter1; the candidate continued in both directions with 13–14 loaded entries. Development RSS stabilized around159.6–175.2MiB in these cases. Startup/immersion timings do **not** establish a general speed improvement; the detailed comparison table and boundaries are included.
- Real native Library installs retained279 Bible/41 commentary row objects with zero model-change events; the same visible surrounding row remained within3/0 logical pixels after the final frame. NT-only Geneva1669 opened Matthew1:1; installing Wesley retained the active Bible.
- Client usability acceptance of #206 is still required. The walkthrough is in the evidence bundle. STEP's available glosses can be English; uncertain place identities and unavailable correspondences are reported locally without invention. Optional reviewed history/photo coverage is currently Jerusalem, not a general encyclopedia service.
- Automated and manual developer validation used Linuxx86_64/X11 and software rendering. It does not establish behavior on the client's GNOME/Wayland/GPU, touch devices, Windows or macOS. A narrow Notes allocation warning is reproducible in both old and new development runtimes; captured editors remain usable within the viewport. Existing source/versification limitations remain applicable.
- Project5 writes remain forbidden with `Resource not accessible by integration`. Once this release is verified, the25 issues are eligible for a **manual In validation** transition; no project status or client acceptance is fabricated, and issues remain OPEN.

## Install or update the signed alpha

```sh
flatpak install --user https://icfmp.github.io/Bible/alpha/Bible.flatpakref
flatpak update --user io.github.icfmp.Bible//alpha
```

Use the signed channel above. The CI's unsigned `master` test bundle is intentionally not attached as a signed-alpha installer. Evidence and provenance assets have SHA256 checksums; open each evidence archive's `overview.html` or README after extraction.


## Historical measured commentary checkpoint



The exact alpha26 application tree was compared against the candidate application
tree through `f527cf1` (the subsequent `b9d4b2f` change only adjusts a host test).
Both used separate marked copies of the same retained test profile and identical
1280×900 geometry, saved DejaVu Serif14, Cairo/X11 GTK4.18.6, Genesis1 and actual
downloaded resources. Startup is a fresh process; OS/file/font caches were not
flushed. Timings end on an after-paint frame with usable text. These are local
development measurements, not installed-Flatpak or client-hardware measurements.

| Bible / commentary | Startup usable text, alpha26 → candidate (ms) | Immersion first / subsequent opens, alpha26 → candidate (ms) | Candidate RSS after cycles1 →8 (MiB) |
| --- | --- | --- | --- |
| BDS / MHC | 1029 →1144 | 220 /175,180 →243 /182,178 | 170.0 →175.2 |
| BDS / Wesley | 881 →791 | 157 /160,165 →252 /165,160 | 161.5 →161.9 |
| Segond / MHC | 1142 →1007 | 202 /182,181 →223 /181,179 | 164.9 →166.6 |
| Segond / Wesley | 954 →871 | 159 /164,165 →184 /164,165 | 159.6 →162.2 |

Alpha26 stops at the actual final Genesis1 entry in each ordinary-scroll case
and cannot turn beyond that chapter in commentary immersion. The candidate
crosses in both directions on all eight cycles of all four combinations, keeps
13–14 loaded entries in these cases, permits immersive continuation, and leaves
notes unchanged. RSS stabilizes instead of growing on every repeated cycle.
These timings do **not** establish a speed improvement: warmed immersion is
comparable, and the native wheel test includes input pacing. Earlier protocols
that seeded the end of the whole moving buffer were rejected: they changed the
tested passage each cycle and cannot support a before/after claim.



## Separate ticket evidence

### #204

Removed redundant reference hover previews; shared native full-card pointer/hover/focus, small arrow and mouse/Enter/Space activation preserve the existing passage destination.

Checks: Native reference actions, real pointer and keyboard activation, independent citation behavior, light/dark Study screenshots and narrow installed Study checks passed.

Evidence: `installed/client-feedback/*-study-references.png; development/{before,after}-{fr,en}/*-study-references.png`

Client validation:
1. Open Study → References at Mark7:1 and hover a card: no duplicate preview should cover its text.
2. Open a reference by clicking unused card space, then by Enter/Space; confirm the expected passage and visible focus.
3. Repeat in a narrow window and dark mode.

### #205

Harmonized compact cards across text/theme results, occurrences, place references, Study Notes/References and Notes management. Summary cards show the user's note and primary reference; metadata stays in the editor. Genuine embedded citation actions remain independent. Static commentary, highlight recolor/remove controls and Library transfer rows retain their appropriate semantics.

Checks: Native pointer/keyboard/citation tests, selected-note state, search matching emphasis and 360px/150% editor checks passed. Actual before/after search, Study and Notes captures and installed place/word captures are supplied.

Evidence: `development/*/search/; development/*/*-note-summary.png; installed/client-feedback/ready-places-*; installed/client-feedback/ready-words-*`

Client validation:
1. Search for ‘je suis le chemin’, compare text/theme results with Study references and a place's references.
2. Open a note card from unused space, then a citation inside it; verify the two distinct destinations.
3. Check Notes management selection and narrow/dark cards.

### #206

Implemented beginner passage → choose Greek/Hebrew word → common meanings → occurrences/back navigation. Actual form/transliteration are prominent; technical lemma/Strong/morphology fields are secondary. Real English STEP glosses are identified as English; no French gloss or Semeur word alignment is invented.

Checks: Actual packaged Semeur download/conversion, offline Mark7:4 Greek καὶ/G2532 and Genesis1:1 Hebrew RTL, native keyboard/occurrence preview/back chain, FR/EN light/dark and unchanged reading position/notes passed. Technical checks do not establish beginner usability acceptance.

Evidence: `semeur/ready-semeur-{fr,en}/; installed/client-feedback/ready-words-{fr,en}/; BEGINNER_WALKTHROUGH.md`

Client validation:
1. In Semeur Mark7:4 choose Original text, then select a Greek word and read Common meanings.
2. Open Other occurrences, preview a passage, and go back to the word and original passage; try Genesis1:1 Hebrew too.
3. Please confirm whether you understand what each screen shows and what to do without developer guidance; report any remaining confusion.

### #207

Replaced custom Library icon uses with dictionary-symbolic and removed the unused custom asset. Because GNOME49 lacks the symbol, the client-approved official upstream CC0 SVG is pinned, bundled and credited.

Checks: Repository use audit, existing Library actions/accessibility and actual installed GNOME49 symbol lookup passed; FR/EN/light/dark screenshots supplied.

Evidence: `semeur/ready-semeur-fr/result.json; installed/client-feedback/*-main-menu.png`

Client validation:
1. Open Library from the menu/header and confirm the dictionary icon and existing action.
2. Repeat offline and in dark mode; check no missing icon.

### #208

Replaced Notes icon uses with notebook-symbolic and Bible/Notes compact switcher with dictionary/notebook. Removed obsolete custom assets; preserved original-language semantic exceptions. The client's explicit SVG approval supersedes the initial no-assets constraint for the exact official CC0 assets.

Checks: Full use audit, native navigation/accessibility and packaged dictionary/notebook lookups passed. Official assets, hashes, creator metadata and license notices are included in the application.

Evidence: `semeur/ready-semeur-fr/result.json; installed/client-feedback/study-narrow.png; development/*/search/*-notes-management.png`

Client validation:
1. Check Notes entry points and the compact Bible/Notes switcher in a narrow window.
2. Navigate with keyboard and compare light/dark themes; confirm no missing icon or changed action.

### #209

Replaced custom biblical-place icon uses with the runtime's mark-location-symbolic, preserving exact place actions and accessible context; removed the unused custom asset.

Checks: Actual GNOME49 lookup, source-marker interaction/navigation tests and real place-window online/offline checks passed.

Evidence: `semeur/ready-semeur-fr/result.json; installed/client-feedback/ready-places-fr/; semeur/ready-places-narrow-dark/`

Client validation:
1. Open a real place marker and confirm the expected place rather than a note/commentary.
2. Check keyboard activation and light/dark rendering.

### #210

Removed the custom filter icon and supplied the approved official filter-symbolic asset with provenance. Coordinated with #231: the redundant wide Notes sidebar toggle is removed, not reintroduced solely to display a filter icon.

Checks: No obsolete custom-filter references remain; packaged filter-symbolic resolves. Existing category/book/label/sort and narrow adaptive sidebar checks passed.

Evidence: `semeur/ready-semeur-fr/result.json; development/*/search/*-notes-management.png`

Client validation:
1. Verify wide Notes has no redundant filter button beside sort.
2. Use category/book/label filters and reach them through the narrow layout's adaptive sidebar control.

### #211

Bundled pinned Roboto/Roboto Serif regular/italic font files and OFL licenses through the existing Flatpak font mechanism. Fresh profiles use the new reading defaults; legacy saved font choices remain unchanged and system controls retain system typography.

Checks: Actual installed offline font resolution points to /app/share/fonts/roboto/Roboto.ttf and RobotoSerif.ttf; preference round trips and retained alpha26→new saved typography passed.

Evidence: `semeur/ready-semeur-fr/result.json; retained/preservation.json; installed/client-feedback/preferences-*.png`

Client validation:
1. Disconnect network and choose Serif/Sans reading styles; verify readable Roboto families.
2. Reopen an existing profile and confirm its saved fonts and study size remain selected.

### #212

Installed valid localized AppStream metadata with desktop identity/icons and a real immutable GTK screenshot. Reproduced alpha26's incomplete GNOME Software page before changing packaging.

Checks: AppStream/desktop validation, installed metainfo and GNOME Software46 local-bundle details passed. After the signed public update, the actual bible-alpha remote page shows Bible, icon, description, screenshot and Open; screenshot personally inspected.

Evidence: `software-before/software-local-bundle.png; semeur/software-local-bundle.png; retained/software-io.github.icfmp.Bible.png`

Client validation:
1. Refresh GNOME Software and open Bible's bible-alpha details.
2. Confirm the application icon/name, description and real screenshot; launch the installed app.

### #213

Refreshes existing Library resource objects and bound rows in place when identity/order are unchanged, retaining GTK's native visual anchoring. Rejected extra focus/scroll-restoration machinery; no forced scroll correction is added.

Checks: 200-row model identity test and actual native-wheel CrossWire Geneva1669/Wesley installs passed:279/41 objects retained, zero items-changed, same displayed surrounding row within3/0 logical pixels after final frame. Numerical adjustment estimates are not mistaken for visible movement.

Evidence: `VALIDATION.md (Library measurements); main CI real CrossWire job`

Client validation:
1. Scroll well down a real Library list and install a Bible without changing filters.
2. Continue scrolling during download; after completion confirm nearby rows remain where expected.
3. Repeat for a commentary and reopen the installed resource.

### #214

Opens a newly usable Bible immediately after first install/startup recovery, using its actual first available passage. Repairs only an unusable active reader; valid Bible/Notes sessions, corrupt files and unsavable drafts are preserved.

Checks: Actual NT-only Geneva1669 opens Matthew1:1; subsequent Wesley installation preserves that Bible. Missing/invalid startup cases, valid session preservation, native SQLite write-prohibition draft guard and repeated install/navigation tests passed.

Evidence: `installed/packaged-youversion-opening.json; VALIDATION.md; main CI native installation/draft checks`

Client validation:
1. Using an empty disposable profile, download a Bible and confirm reading opens immediately.
2. Use an NT-only edition and verify its actual first book rather than a blank Genesis view.
3. On your existing profile install another resource and confirm your active passage/notes stay intact.

### #218

Added separately maintained, documented place context keyed by stable OpenBible identity, reviewed Jerusalem history and explicitly downloaded licensed/hash-checked photo with bounded cache/full viewer. Emmaus stays disputed and Nod unknown. Existing native libshumate patch fixes a measured lost one-shot tick, without polling or disabling deferral.

Checks: Real HTTP/cache/error/no-request-after-close checks,128 controlled native map cases, actual installed Jerusalem/Emmaus/Nod online/offline checks,360px dark hero/full viewer and image hash/license verification passed. Reviewed history/photo coverage is currently Jerusalem; no invented coordinates or broad encyclopedia coverage.

Evidence: `installed/client-feedback/ready-places-fr/; installed/client-feedback/ready-places-offline-en/; semeur/ready-places-narrow-dark/`

Client validation:
1. Open Jerusalem, read its source/history and explicitly load the photo; reopen it offline and open full image.
2. Check its Bible reference cards and a narrow dark window.
3. Open Emmaus and Nod: uncertainty/unavailable location must remain explicit.

### #219

Removed redundant standalone translation-notes Study page/action; retained inline exact-locator translation notes and safe legacy-tool fallback to an available Study tab.

Checks: Native inline mouse/keyboard and chapter-change checks passed; real installed source-note tests and unchanged underlying text/data passed.

Evidence: `installed/client-feedback/*-study-notes.png; main CI selection/inline checks`

Client validation:
1. Check Study header has no redundant translation-notes page.
2. Open an inline translation-note marker by mouse and keyboard and verify its exact note after changing chapters.

### #220

Uses the approved official talking-symbolic as a small raised gray inline source-note marker, preserving exact locator, tooltip/popover and accessible reference context.

Checks: Packaged icon lookup plus native pointer/keyboard activation, multiple-note locator identity and chapter changes passed; source text remains unchanged.

Evidence: `semeur/ready-semeur-fr/result.json; main CI native source-note checks`

Client validation:
1. Find a translation note and inspect its small raised gray marker in light/dark themes.
2. Activate it by pointer and keyboard; verify exact note/reference rather than a place or commentary action.

### #221

Moved loading spinner into Submit, compacted scope selection and removed redundant instructions. Previous text results remain visible but inert while typing/pending; matching emphasis stays tied to their real query and stale responses cannot replace current results.

Checks: Controlled pending/stale/empty-query tests and actual FR/EN before/after phrase/theme result captures passed; search algorithms and result content are unchanged.

Evidence: `development/*/search/*-text-results.png; development/*/search/*-themes.png; main CI asynchronous search checks`

Client validation:
1. Search text with Enter in the active Bible and check the compact scope/loading button.
2. Change query during a search; verify old results cannot navigate while pending and current results retain correct match emphasis.
3. Compare Themes and a narrow window.

### #222

Removed commentary overflow without losing unique sparse previous/next or source preface actions, now retained in the native text context menu; existing Library attribution/download access remains.

Checks: Source preface fidelity, sparse navigation, native text-menu checks and actual installed commentary reading passed.

Evidence: `installed/client-feedback/*-study-commentary.png; development/*/*-study-commentaries.png`

Client validation:
1. Open a commentary: no redundant three-dot header menu should remain.
2. Use the text context menu for unique navigation/preface actions; verify source text and Library details remain accessible.

### #223

Uses three lightweight underlined native Study tabs, one passage reference heading, theme-aware surfaces and quiet empty states; shared reading typography and existing actions remain.

Checks: Three-tab native checks, French/English light/dark before/after captures, installed high-contrast/narrow and study scrolling passed.

Evidence: `installed/client-feedback/*-study-*.png; development/*/*-study-*.png`

Client validation:
1. Switch Notes, References and Commentaries and confirm one passage heading and consistent alignment.
2. Try an empty passage and populated passage, then narrow/dark mode.

### #224

Grouped Aa into Text/Appearance, stable adaptive width, labeled advanced settings row and2×2 palette choices. Visible elements starts collapsed only for fresh preferences; existing saved/missing legacy expansion choices remain preserved.

Checks: Independent reading/study fonts and preference round trips, actual offline packaged fonts, FR/EN/light/dark Aa and narrow large-text Preferences captures passed.

Evidence: `development/*/*-appearance.png; installed/client-feedback/preferences-*.png`

Client validation:
1. Open Aa, adjust common text and palette controls, then open advanced Preferences.
2. Reopen the app and verify your fonts, study size, palette and expansion choices persist.
3. Check a small window with larger interface text.

### #225

Paints exactly one native1-logical-pixel separator at the Study boundary, retaining the independent8px pointer/focusable resize target and stored width.

Checks: Actual pixel checks found one contiguous pixel at scale1 and2 physical pixels at scale2 across light/dark/high contrast. Pointer drag, keyboard resizing, saved width/reopen, adaptive collapse and actual installed Study checks passed.

Evidence: `installed/client-feedback/*-study-*.png; VALIDATION.md (native scale1/scale2 measurements)`

Client validation:
1. Inspect the full Study boundary in light/dark: one line, without an adjacent second edge.
2. Resize by pointer and keyboard, close/reopen and confirm width persists.
3. Repeat at your display scaling and a narrow width.

### #226

Added a labeled Introduction action beside books that supply one; displays a book-specific heading and bounded native reading column with faithful supported source paragraphs/headings/emphasis/lists. Source wording/order and selection/copy are preserved.

Checks: Nested rich/plain-source fidelity tests, actual packaged BDS Jeremiah and other-edition introduction paths, FR/EN light/dark wide/narrow selection through the final paragraph passed.

Evidence: `semeur/ready-semeur-{fr,en}/*jeremiah*; installed/client-feedback/ready-words-{fr,en}/*jeremiah*; development/*/*-passage-picker.png`

Client validation:
1. In Semeur choose Jeremiah and open the labeled Introduction action.
2. Read/copy source headings and paragraphs, then scroll/select the final paragraph in a narrow window.
3. Try another book/edition, including one without an introduction.

### #227

Restored visible localized Original text label with its existing icon and native wrapping/height measurement; preserved action order, selected passage and GTK/GSK cached backdrop lifecycle.

Checks: Native mouse/keyboard Copy/highlight/note/parallel/immersion checks, narrow bounds, actual Semeur original-word opening, software-GL blur/cache and first-event dismissal measurements passed. Forced background movement while artificially keeping the toolbar visible remains expensive and is disclosed in release measurements.

Evidence: `installed/client-feedback/*-selection.png; development/*/*-selection.png; installed/client-feedback/scroll-gl-single-toolbar.json; installed/client-feedback/live/live-report.json`

Client validation:
1. Select Bible text and confirm the visible Original text label; open the correct selected passage.
2. Try a narrow window, Copy, highlight, Note and keyboard activation.
3. Scroll with the bar open: it should disappear on the first gesture without delaying movement.

### #228

Extends existing commentary entries across chapter boundaries in ordinary/immersive reading with a bounded20-entry window, shared text marks and stale-intent handling. Bible loading is unchanged; sparse/uncertain sources retain existing reference safeguards.

Checks: Eight real forward/reverse cycles each for BDS/Segond × MHC/Wesley, including immersion, passed; alpha26 stopped at chapter1. Candidate kept13–14 entries in those cases and RSS stabilized. Exact installed immersion/scroll suites passed. Development timing table does not claim a general speed gain.

Evidence: `VALIDATION.md commentary measurements; main CI installed commentary/immersion/navigation checks`

Client validation:
1. With Semeur or Segond and MHC/Wesley, scroll commentary across Genesis1→2 and back repeatedly.
2. Repeat in commentary immersion and switch passage/resource quickly; check correct text and existing following rules.
3. Try a sparse entry and verify missing content is not replaced by unrelated commentary.

### #230

Polished all four note surfaces: quick, expanded inline, workspace and collapsed summary. Editors group read-only source context → My note → labels → links, bounded editing, contextual Bible opening and safe confirmed deletion; summary follows #205's user-note preview. No schema/editor-framework change.

Checks: Actual matched alpha26/b814 FR/EN light/dark wide/narrow before/after captures of every surface passed with synthetic notes unchanged. Native citation/formatting/expansion/360px/150%/draft guards, legacy/new backup and linked-reference restoration passed. Old temporary captures were lost on resume and honestly recreated at exact sources on8Nov.

Evidence: `development/{before,after}-{fr,en}/*-note-{summary,inline,quick,workspace}.png; retained/preservation.json; main CI backup/draft checks`

Client validation:
1. Open the same short/long note in quick, inline and workspace views; check readable source context, labels, links and visible deletion confirmation.
2. Edit formatting/links, expand the inline editor and reopen; confirm no duplicate/missing text or lost edits.
3. Export/restore notes and check original and linked passages, including an older backup.

### #231

Removed the permanent wide Notes Filters sidebar-toggle button and dead wiring; retains one appropriate adaptive header sidebar control when collapsed, with existing filters/sort/selection preserved.

Checks: Native sidebar/filter/state and keyboard checks, FR/EN wide/narrow Notes/editor captures and installed workspace checks passed.

Evidence: `development/*/search/*-notes-management.png; development/*/*-note-workspace.png`

Client validation:
1. Open wide Notes: no filter icon beside sorting; use category/book/label filters.
2. Shrink the window and use the adaptive header control to reach filters/list and return to the editor.
3. Confirm selected note, search and sort remain intact.

### #232

Removed prominent Resume following and All my annotations buttons and gaps, retaining shared follow APIs, manual Notes browsing, draft safeguards and main Bible/Notes navigation.

Checks: Real Bible wheel/navigation resumes following; manual Notes wheel suspends it without navigating. Empty/populated Notes, unchanged drafts, stable cards and installed workspace/scroll tests passed.

Evidence: `installed/client-feedback/*-study-notes.png; development/*/*-note-summary.png; main CI native Notes-follow/draft checks`

Client validation:
1. Open Study → Notes and check neither redundant text button remains; use main Notes navigation.
2. Browse Notes independently, then deliberately navigate/scroll the Bible and confirm following resumes.
3. Keep an edited draft open during navigation and confirm save/unsaved safeguards still work.
