# Bible alpha27 — native-before-after

Exact alpha26 versus merged b814 source, matched saved DejaVu Serif14. Actual development GTK4.18.6/X11/Cairo; French/English, light/dark, wide/narrow. Four note surfaces, search, Study, Aa, selection and navigation. Recreated on8Nov after temporary files were lost. These are not installed-Flatpak images.

Open overview.html for the original unedited PNGs. See VALIDATION.md for actual checks, measurements, source boundaries and client steps. SHA256SUMS covers every evidence file. No profiles, databases, full Bible modules, credentials or unsigned test installers are included. All issues remain open for client acceptance.
