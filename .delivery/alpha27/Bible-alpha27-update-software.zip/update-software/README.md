# Bible alpha27 — update-software

Actual signed retained-profile alpha26→new update and GNOME Software46. Before local bundle generic page, after candidate local bundle and final signed-remote details are distinct checks. The baseline offers Install and installed candidate offers Open because of installation state; this button change alone is not evidence of the metadata fix.

Open overview.html for the original unedited PNGs. See VALIDATION.md for actual checks, measurements, source boundaries and client steps. SHA256SUMS covers every evidence file. No profiles, databases, full Bible modules, credentials or unsigned test installers are included. All issues remain open for client acceptance.
