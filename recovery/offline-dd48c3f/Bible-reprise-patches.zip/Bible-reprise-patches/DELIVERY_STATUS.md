# Delivery status — 22 October 2026

Saved: fa2bfa0 and dd48c3f, exact base and head in manifest.json. The full Git
bundle was verified, cloned into a temporary empty directory without a remote,
and checked with git fsck --full. Recovered HEAD and tree match exactly. The
cumulative binary patch was checked/applied against the exact base, and its
resulting tree also matches the final commit.

Source test evidence is recovered from the preceding offline work: 34 passed,
five GTK/display skips. Those product tests were not rerun during export. The
new validation in this delivery is archive/bundle/patch recoverability.

One bounded executor network probe failed immediately (curl exit 7):
Failed to connect to proxy port 8080 after 0 ms: Could not connect to server.
No retry, Docker diagnostic, push, PR, remote CI or publication was attempted
after that failure. Environment readiness reported an enforced unrestricted
policy, but that did not establish working executor egress.

Nothing new is published. The latest saved signed proof remains 6560dc4, alpha
revision 39674239853-2; it has not been refreshed remotely. No signing key,
channel setting, personal data or ticket acceptance state was changed.

Remaining checks, in order after environment/network recovery:
1. Push feat/24-offline-preparation and open a review PR. Run native GTK and an
   actual constructed/installed Flatpak for #24: Mark 7/8 and Luke 13/14 titles
   on both pages, rapid resize/Aa, cache reuse, interruption/exit and canonical
   position preservation. Package checks must assert imports from /app.
2. Recover the official AndBible/JSword revisions, conversion mechanisms and
   tables listed in BILAN.md. Verify exact forward/reverse Luther alignment
   including Psalms/ranges/missing verses and non-Darby controls. Preserve the
   explicit unsupported state until verified; no numeric/identity fallback.
3. In the actual package, verify the retained #53–56 sidebar/Aa/arrows/resource
   installation behavior and data preservation. Complete CI/build gates, then
   verify the existing signed channel's new provenance and actual update before
   announcing an alpha. Keep client GNOME/Wayland/accessibility checks open.
