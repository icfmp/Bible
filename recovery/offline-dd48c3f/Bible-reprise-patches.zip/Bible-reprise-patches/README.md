# Bible offline recovery — lightweight delivery

This archive contains the two commits as Git format-patch mail, a cumulative
binary-capable patch, the exact base/head manifest, and the saved report/evidence.
Unlike Bible-offline.bundle, it requires an existing repository with the base.

Exact base: 884591cd194bd7c07e3534a9b652c154a578dd34
Original final commit: dd48c3f56509079017c950582c49fc6cbe8304f6
Original commits: fa2bfa02f6aeb640f134bda0abf7f4a30a1e1911, dd48c3f56509079017c950582c49fc6cbe8304f6

In a clean existing repository, use ONE method:

1. Preserve authorship and both commits with git am:

    git switch -c recovery/24-offline 884591cd194bd7c07e3534a9b652c154a578dd34
    git am /absolute/path/to/commits.mbox

Recreated commit hashes may differ because committer metadata is new.

2. Apply the combined changes only:

    git switch -c recovery/24-offline 884591cd194bd7c07e3534a9b652c154a578dd34
    git apply --check /absolute/path/to/cumulative.patch
    git apply /absolute/path/to/cumulative.patch

Both patches are against the exact base above. No secrets, user profiles or
signing keys are included. This is source recovery, not a published alpha.
