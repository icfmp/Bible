rootProject.name = "jsword"

