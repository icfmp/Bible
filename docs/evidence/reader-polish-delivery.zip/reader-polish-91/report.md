# Reader polish: #64, #66, #69 and icon-only #67

PR: https://github.com/icfmp/Bible/pull/91
Reviewed source: 50a75a23d0670179bd30cc92fa7b065c3982bca7
Merged source (identical tree): 044d81ea09b0bbd4eaf1b0f4b88fa24d1f557691
Baseline: 275fe841cdf970810c120d72e55ae4063caf71aa

The batch coordinates Aa and installed Bible version controls without duplicated
visible choosers, aligns comparison headings, improves selection actions and
harmonizes Header Bar icons. The existing action order, Library and Notes access
are preserved. #71/#75 are excluded. Numbered release #87 remains paused.

Open galerie.html for the before/after gallery. All PNGs are unretouched GTK
captures. There are 149 captures and 70 matched pairs, including French/English,
light/dark, constrained windows, study on/off, immersion and HiDPI. Additional
captures cover 150% system text and emulated high contrast. Xvfb and emulated
settings notifications do not prove manual GNOME/Wayland accessibility acceptance.

Validation reports are in verifications/. Local suite: 231 tests passed with one
skip; affected suite: 21 passed. Remote CI: 231 tests passed without a skip and
72 French UI tests passed, plus native input and real offline resource checks.

Actual Segond/Darby/KJV text fidelity and both scrolling directions passed in all
six pane roles. Darby Gen.32.1 ↔ KJV Gen.31.55, direct pane choosers, independent
tabs and shared immersive control round trips passed. A profile created with the
baseline source retained its actual SQLite note/labels, highlight, explicit
appearance preferences, primary/comparison session and all 36 resource-file hashes.

Signed alpha publication succeeded:
https://github.com/icfmp/Bible/actions/runs/39980683771

Public source: 044d81ea09b0bbd4eaf1b0f4b88fa24d1f557691
Packaging revision: 39980683771-2
Installed final OSTree commit: 1a1e89b4480702a642b0d51db6facea7bd0e8d004a26f6a21146482bae7ba3cf
The existing remote, ref and signing fingerprint are unchanged. Public installation,
GTK startup, GPG commit/summary verification, real Flatpak update and preservation
of the update client's data snapshot all passed. This complements the actual
baseline SQLite-note/preferences/session/resource preservation check above.

One application batch was published through the existing channel. The publication
workflow's two verification revisions are the established install/update test.
No numbered prerelease was created: the release list is unchanged and #87 is paused.

Update the existing installation:

    flatpak update io.github.icfmp.Bible//alpha

Three quick checks: adjust Aa while reading; change each comparison pane's version;
select a passage and use Copy/Highlight/Note, then resize and switch light/dark.


Branch CI: https://github.com/icfmp/Bible/actions/runs/39977795018

Main CI: https://github.com/icfmp/Bible/actions/runs/39979270368
